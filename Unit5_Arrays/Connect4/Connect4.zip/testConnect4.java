package Unit5_Arrays.Connect4;

/**
 * User: 67364
 * Date: 23/03/22
 */
public class testConnect4 {
    public static void main(String[] args) {
        Connect4 game = new Connect4();
        game.gameLoop();
    }
}
